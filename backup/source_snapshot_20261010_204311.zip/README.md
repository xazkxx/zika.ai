# ERP 管理系统

本地部署的 ERP 系统：电脑桌面版 + 手机 PWA + 鸿蒙 App 外壳，带发票 OCR 智能解析。

## 技术栈

| 层 | 技术 |
|---|---|
| 后端 | Python 3.12 + FastAPI + SQLAlchemy |
| 数据库 | PostgreSQL 18（本地服务 postgresql-x64-18） |
| 前端 | React + Vite（构建产物由后端直接挂载，一个端口全包） |
| 桌面版 | PyInstaller 打包（dist\ERP管理系统\ERP管理系统.exe） |
| 手机 | PWA（浏览器访问即可安装）+ 鸿蒙 App（harmonyos/ 工程） |
| 发票解析 | 二维码（OpenCV）→ PDF 文本层 → OCR（RapidOCR）三关流水线 |

## 端口分配

| 端口 | 用途 | 说明 |
|---|---|---|
| 8000 | ERP 后端 | 监听 0.0.0.0，电脑本机和局域网手机共用 |
| 5432 | PostgreSQL 数据库 | 本地服务，自动启动 |
| 5173 | 前端开发调试 | 仅 `npm run dev` 时用（HTTPS），平时不占 |
| 8000（WSL 内） | ERPNext web | ⚠️ 已停用，自启动已关（见"常见问题"） |

## 目录结构

```
E:\AI\ERP软件\
├── app\                 后端源码（FastAPI，接口在 app/api/v1/routes/erp.py）
├── frontend\            前端源码（React，单文件 src/App.jsx）
│   └── dist\            前端构建产物（后端 8000 端口直接挂载这个目录）
├── harmonyos\           鸿蒙 App 工程（用 DevEco Studio 打开编译）
├── dist\ERP管理系统\    桌面版打包成品（exe 在这里）
├── tests\               后端测试（40 个，pytest）
├── scripts\             工具脚本（SQLite→PG 数据迁移）
├── backup\              数据库自动备份（每天 21:37，保留 14 份）
├── test_invoices\       发票测试样本
├── .venv\               Python 虚拟环境（不要删）
├── .env                 环境配置（数据库连接、密钥，不要外传）
├── desktop_app.py       桌面版启动器源码
├── 启动ERP.bat           一键启动脚本（无黑窗口）
├── erp.spec             PyInstaller 打包配置
└── requirements.txt     Python 依赖清单
```

## 启动方式（三选一）

### 方式一：桌面版 exe（最常用）
双击桌面快捷方式「ERP管理系统」，或运行 `dist\ERP管理系统\ERP管理系统.exe`。
窗口打开即用；exe 会自动在后台起后端（8000），手机同时可访问。

### 方式二：一键启动脚本
双击根目录的 `启动ERP.bat`（用源码起后端，无黑窗口，效果与桌面版相同）。

### 方式三：命令行启动后端（开发调试用）
```powershell
# 进入项目目录后：
$env:DEEPSEEK_API_KEY = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY','User')
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## 手机访问（PWA）

1. 手机和电脑连**同一个 WiFi**
2. 浏览器打开 `http://192.168.3.7:8000`（电脑局域网 IP，变了就问）
3. 浏览器菜单 → 「添加到主屏幕」即可装成 App

前提：电脑上 ERP 开着（桌面版或后端任一在跑），防火墙已放行 8000 端口（规则名"ERP管理系统8000"）。

## 账号密码

| 用途 | 账号 | 密码 |
|---|---|---|
| ERP 登录 | admin | Admin123 |
| PostgreSQL | erp | erp123456 |

完整凭据清单在桌面《ERP环境账号密码.txt》（含 AI Key 的查看命令，不写明文）。

## 数据库与备份

- 数据库服务：`postgresql-x64-18`（Windows 服务，开机自启）
- 自动备份：每天 21:37（Windows 计划任务"ERP数据库备份"），文件在 backup\ 目录，保留 14 份
- 手动备份：`& 'E:\AI\ERP软件\backup\backup.ps1'`

## 测试与打包

```powershell
# 跑测试（40 个；注意不要注入 DEEPSEEK_API_KEY，测试断言本地兜底）
.\.venv\Scripts\python.exe -m pytest tests\ -q

# 重新打包桌面版（先关闭 exe 进程，PowerShell 不要在 dist 目录里）
.\.venv\Scripts\python.exe -m PyInstaller erp.spec --noconfirm --clean
```

## 常见问题

1. **桌面版窗口显示 404**：WSL 里的 ERPNext 抢了 8000 端口。
   停掉它：`wsl -u root -e sh -c "supervisorctl stop frappe-bench-web:frappe-bench-frappe-web"`
   （它的自启动已关闭，重启电脑不会再抢；想恢复 ERPNext 再单独处理。）

2. **手机打不开**：确认电脑上 ERP 在跑、手机电脑同一 WiFi、电脑 IP 还是 192.168.3.7。

3. **发票解析结果不对**：发票文件放到 test_invoices\，上传到系统里试；重点看"查看"详情里的二维码字段。

4. **桌面上传发票闪退/报错**：桌面版 exe 版本旧，需要重新打包（见上）。

## 版本记录

- 2026-09：发票模块完整上线（三关解析流水线、批量勾选删除、去重替换、勾选导出 Excel）
- 2026-09-25：数电票兜底提取（标签数值分离版面）、桌面版 19:58 版、手机 PWA 局域网打通
- 2026-10-09：解决 ERPNext 端口冲突，文档整理
