"""Core application settings."""
