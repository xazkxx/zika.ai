"""ERP application package."""
