from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class UserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: str
    full_name: Optional[str] = None
    role: str = "staff"
    password: str = Field(..., min_length=6)


class UserRead(BaseModel):
    id: int
    username: str
    email: str
    full_name: Optional[str] = None
    role: str = "staff"
    is_active: bool = True
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class UserLogin(BaseModel):
    username: str
    password: str


class Token(BaseModel):
    access_token: str
    token_type: str = 'bearer'
    role: str = 'staff'
    model_config = ConfigDict(from_attributes=True)


class CustomerCreate(BaseModel):
    code: str
    name: str
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None


class CustomerRead(CustomerCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class SupplierCreate(BaseModel):
    code: str
    name: str
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None


class SupplierRead(SupplierCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class ProductCreate(BaseModel):
    sku: str
    name: str
    category: Optional[str] = None
    unit: Optional[str] = None
    purchase_price: float = 0.0
    sale_price: float = 0.0


class ProductRead(ProductCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class PurchaseOrderItemCreate(BaseModel):
    product_id: int
    quantity: int
    unit_price: float


class PurchaseOrderCreate(BaseModel):
    supplier_id: int
    order_no: str
    items: list[PurchaseOrderItemCreate]


class PurchaseOrderItemRead(PurchaseOrderItemCreate):
    id: int
    purchase_order_id: int
    amount: float
    model_config = ConfigDict(from_attributes=True)


class PurchaseOrderRead(BaseModel):
    id: int
    order_no: str
    supplier_id: int
    status: str
    total_amount: float
    created_at: datetime
    items: list[PurchaseOrderItemRead] = []
    model_config = ConfigDict(from_attributes=True)


class SalesOrderItemCreate(BaseModel):
    product_id: int
    quantity: int
    unit_price: float


class SalesOrderCreate(BaseModel):
    customer_id: int
    order_no: str
    items: list[SalesOrderItemCreate]


class SalesOrderItemRead(SalesOrderItemCreate):
    id: int
    sales_order_id: int
    amount: float
    model_config = ConfigDict(from_attributes=True)


class SalesOrderRead(BaseModel):
    id: int
    order_no: str
    customer_id: int
    status: str
    total_amount: float
    created_at: datetime
    items: list[SalesOrderItemRead] = []
    model_config = ConfigDict(from_attributes=True)


class InventoryTransactionCreate(BaseModel):
    product_id: int
    warehouse_id: int
    transaction_type: str
    quantity: int
    unit_price: float = 0.0


class InventoryTransactionRead(InventoryTransactionCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class FinancialTransactionCreate(BaseModel):
    transaction_type: str
    amount: float
    currency: str = "CNY"
    note: Optional[str] = None
    related_order_id: Optional[int] = None
    customer_id: Optional[int] = None
    supplier_id: Optional[int] = None


class FinancialTransactionRead(FinancialTransactionCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class InvoiceCreate(BaseModel):
    invoice_no: str
    invoice_type: str = "普票"
    issue_date: Optional[str] = None
    counterparty_name: Optional[str] = None
    invoice_code: Optional[str] = None
    total_amount: float = 0.0
    tax_rate: Optional[float] = None
    tax_amount: Optional[float] = None
    excl_tax_amount: Optional[float] = None
    deducted: bool = False
    category: Optional[str] = None
    status: Optional[str] = None
    buyer_name: Optional[str] = None
    buyer_tax_no: Optional[str] = None
    seller_name: Optional[str] = None
    seller_tax_no: Optional[str] = None
    items: list[dict] = []
    raw_text: Optional[str] = None


class InvoiceUpdate(BaseModel):
    invoice_type: Optional[str] = None
    deducted: Optional[bool] = None
    category: Optional[str] = None
    status: Optional[str] = None


class InvoiceRead(InvoiceCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class BillOfMaterialCreate(BaseModel):
    product_id: int
    component_product_id: int
    quantity: int = 1
    unit_cost: float = 0.0
    note: Optional[str] = None
    parent_id: Optional[int] = None
    name: Optional[str] = None
    code: Optional[str] = None
    bom_type: str = "component"
    level: int = 0
    description: Optional[str] = None


class BillOfMaterialRead(BillOfMaterialCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class ProductionOrderCreate(BaseModel):
    product_id: int
    bom_id: Optional[int] = None
    order_no: str
    quantity: int = 1
    status: str = "planned"
    priority: str = "normal"
    note: Optional[str] = None


class ProductionOrderRead(ProductionOrderCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)


class ProjectCreate(BaseModel):
    code: str
    name: str
    manager: Optional[str] = None
    status: str = "planned"
    progress: int = 0
    budget: float = 0.0
    deadline: Optional[str] = None
    note: Optional[str] = None


class ProjectRead(ProjectCreate):
    id: int
    created_at: datetime
    model_config = ConfigDict(from_attributes=True)
