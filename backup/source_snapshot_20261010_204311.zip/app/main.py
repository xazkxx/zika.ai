import sys
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import inspect, text

from app.api.v1.router import api_router
from app.core.security import get_password_hash
from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.models.user import User


def ensure_database_schema() -> None:
    with engine.begin() as conn:
        if not inspect(conn).has_table("users"):
            return

        columns = [column["name"] for column in inspect(conn).get_columns("users")]
        if "role" not in columns:
            conn.execute(text("ALTER TABLE users ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'staff'"))
            conn.execute(text("UPDATE users SET role = 'staff' WHERE role IS NULL"))

        if inspect(conn).has_table("production_orders"):
            production_columns = [column["name"] for column in inspect(conn).get_columns("production_orders")]
            if "bom_id" not in production_columns:
                conn.execute(text("ALTER TABLE production_orders ADD COLUMN bom_id INTEGER"))

        if inspect(conn).has_table("production_boms"):
            bom_columns = [column["name"] for column in inspect(conn).get_columns("production_boms")]
            bom_additions = {
                "parent_id": "INTEGER",
                "name": "VARCHAR(150)",
                "code": "VARCHAR(80)",
                "bom_type": "VARCHAR(50) DEFAULT 'component'",
                "level": "INTEGER NOT NULL DEFAULT 0",
                "description": "VARCHAR(255)",
            }
            for column_name, definition in bom_additions.items():
                if column_name not in bom_columns:
                    conn.execute(text(f"ALTER TABLE production_boms ADD COLUMN {column_name} {definition}"))


def ensure_default_admin_user() -> None:
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.username == "admin").first()
        if user is None:
            db.add(
                User(
                    username="admin",
                    email="admin@example.com",
                    full_name="管理员",
                    role="admin",
                    hashed_password=get_password_hash("Admin123"),
                    is_active=True,
                )
            )
            db.commit()
    finally:
        db.close()


def create_app() -> FastAPI:
    app = FastAPI(
        title="ERP 核心系统",
        version="0.1.0",
        description="本地 ERP 基础版本，支持采购、销售、库存、财务和报表基础能力。",
    )
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # 开发环境直接允许所有
        allow_credentials=False, # 这里必须是 False，因为 "*" 和 True 不能共存
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    app.include_router(api_router, prefix="/api/v1")
    Base.metadata.create_all(bind=engine)
    ensure_database_schema()
    ensure_default_admin_user()

    # 桌面端/生产模式：后端直接托管前端构建产物（frontend/dist），
    # 这样桌面窗口只需访问 http://127.0.0.1:8000 一个端口。
    # PyInstaller 打包后资源解包到 _MEIPASS，路径需相应切换。
    if getattr(sys, "_MEIPASS", None):
        frontend_dist = Path(sys._MEIPASS) / "frontend" / "dist"
    else:
        frontend_dist = Path(__file__).resolve().parent.parent / "frontend" / "dist"
    if frontend_dist.exists():
        app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="frontend")

    return app


app = create_app()